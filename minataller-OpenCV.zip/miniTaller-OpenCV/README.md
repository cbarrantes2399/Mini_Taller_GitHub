# miniTaller-OpenCV
Primero debe haber instalado Jupyter Notebook y python para poder correrlo,
puede clonar el repositorio o bien descargar un comprimido del mismo,
las herramientas estarán disponibles entre el archivo llamado
'miniTaller_OpenCV.pdf' y el script 'miniTaller_OpenCV.ipynb'
